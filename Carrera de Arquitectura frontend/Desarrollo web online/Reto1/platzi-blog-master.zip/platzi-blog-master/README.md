# platzi-blog
primer reto de el curso de desarrollo web - crear el CSS y HTML del blog de Platzi.

https://leonidasesteban.github.io/platzi-blog/
